When using the package, the interaction and the controllers wont work so it is recommended to
clone the project repository which will be public till the project is graded:
    - https://github.com/Myjoyysr/temp_vr_project.git



However, if the package have to be used:
Before importing the project from the package:
    - need to install openxr plugin
    - need to install xr plugin management
    - need to install xr interaction toolkit
    - need to install shader-graph
    - need to install post processing

After importing packages above the project packages can be imported...

Before running the project following needs to be done:
    - Project Settings -> XR-Plug-in management -> OpenXR checked
    - Project Settings -> XR-Plug-in management -> OpenXr Render Mode = Multi-pass
